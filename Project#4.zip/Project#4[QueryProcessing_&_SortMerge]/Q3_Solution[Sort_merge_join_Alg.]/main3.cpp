#include <iostream>
#include <fstream>
#include <cstring>
#include <stdlib.h>
#include <stdio.h>
// DEBUG mode prints extra stuff to cerr and doesn't delete the tmpfiles
#define DEBUG false

using namespace std;

const int NUM_BLOCKS = 22;  // available memory

const char* DEPT_FILENAME = "Dept.csv";
const char* EMP_FILENAME = "Emp.csv";
const char* OUTPUT_FILENAME = "join.csv";
const char* TMP_FILENAME_TEMPLATE = "main3_tmp%02d.csv";
const int TMP_FILENAME_MAX_LENGTH = strlen(TMP_FILENAME_TEMPLATE) + 6;
int tmp_file_idx = 1;

// Helper function to open a numbered temporary file
void tmpOpen(ifstream &f, int idx) {
    char *filename = new char[TMP_FILENAME_MAX_LENGTH + 1];
    snprintf(filename, TMP_FILENAME_MAX_LENGTH + 1, TMP_FILENAME_TEMPLATE, idx);
    f.open(filename, ios::in);
    delete filename;
}

void tmpOpen(ofstream &f, int idx) {
    char *filename = new char[TMP_FILENAME_MAX_LENGTH + 1];
    snprintf(filename, TMP_FILENAME_MAX_LENGTH + 1, TMP_FILENAME_TEMPLATE, idx);
    f.open(filename, ofstream::trunc);
    delete filename;
}

// We use C-style strings so the content is directly inside the struct.
typedef struct {
    int did;
    char dname[40];
    double budget;
    int managerid;
} DeptTuple;

typedef struct {
    int eid;
    char ename[40];
    int age;
    double salary;
} EmpTuple;


// A tuple, which may be either an Emp or a Dept
typedef union {
    DeptTuple dept;
    EmpTuple emp;
} Tuple;

// An exception for signaling EOF
struct NoMoreTuplesException : public exception {
    const char *what() const throw() {
        return "EOF";
    }
};

// Load one Emp tuple from an already-open Emp.csv file
EmpTuple loadEmp(ifstream &in) {
    char line[80];
    EmpTuple emp;
    in.getline(line, 80);
    if (in.eof()) throw NoMoreTuplesException();
    emp.eid=atoi(strtok(line, ","));
    strncpy(emp.ename, strtok(NULL, ","), 40);
    emp.age=atoi(strtok(NULL, ","));
    emp.salary=atof(strtok(NULL, "\n"));
    return emp;
}

// Load one Dept tuple from an already-open Emp.csv file
DeptTuple loadDept(ifstream &in) {
    char line[80];
    DeptTuple dept;
    in.getline(line, 80);
    if (in.eof()) throw NoMoreTuplesException();
    dept.did=atoi(strtok(line, ","));
    strncpy(dept.dname, strtok(NULL, ","), 40);
    dept.budget=atof(strtok(NULL, ","));
    dept.managerid=atoi(strtok(NULL, "\n"));
    return dept;
}

// Our limited internal memory is simulated by this global array of Tuple.
// Tuple is a union type, so use mem[i].dept or mem[i].emp to access an
// entry as a Dept or as an Emp.
Tuple mem[22];

// Helper function to write an EmpTuple as a CSV line, used by external sort
void writeEmp(ostream &out, EmpTuple emp) {
    out << emp.eid << "," << emp.ename << "," << emp.age << "," << (long)emp.salary
        << endl;
}

// Helper function to write a DeptTuple, unused except maybe for debug
void writeDept(ostream &out, DeptTuple dept) {
    out << dept.did << "," << dept.dname << "," << (long)dept.budget << "," << dept.managerid
        << endl;
}

// Helper function to write one CSV line of the join, once a match is found
void writeJoin(ostream &out, DeptTuple dept, EmpTuple emp) {
    out << dept.did << "," << dept.dname << ","
        << (long)dept.budget << "," << dept.managerid << ","
        << emp.eid << "," << emp.ename << "," << emp.age << ","
        << (long)emp.salary << endl;
}

// Comparator function for qsort and merging
int empCompar(const void* p1, const void* p2) {
    if (((Tuple *)p1)->emp.eid < ((Tuple *)p2)->emp.eid) return -1;
    if (((Tuple *)p1)->emp.eid > ((Tuple *)p2)->emp.eid) return 1;
    return 0;
}

// Comparator function for qsort, on the managerid field followed by did
// This actually results in a descending sort, to help with memory management.
int deptCompar(const void* p1, const void* p2) {
    if (((Tuple *)p1)->dept.managerid < ((Tuple *)p2)->dept.managerid) return 1;
    if (((Tuple *)p1)->dept.managerid > ((Tuple *)p2)->dept.managerid) return -1;
    if (((Tuple *)p1)->dept.did < ((Tuple *)p2)->dept.did) return 1;
    if (((Tuple *)p1)->dept.did > ((Tuple *)p2)->dept.did) return -1;
    return 0;
}

// Perform external sort of Emp.csv on eid and return the index of the
// sorted file.  Emp.csv is too big to fit in mem but not by much.
// We'll use a traditional 2-way merge sort.  We'll use input buffers
// for the sorted chunks, because only 22 tuples can be in memory
// at any time.
int external_emp_sort() {
    int min_tmp_idx = tmp_file_idx;
    int max_tmp_idx = tmp_file_idx;

    // Load parts of Emp.csv, save chunks sorted on eid as temporary files
    ifstream empfile;
    empfile.open(EMP_FILENAME, ifstream::in);
    bool theresMore = true;
    while (theresMore) {
        int mem_idx = 0;
        try {
            // load up to NUM_BLOCKS tuples
            while (mem_idx < NUM_BLOCKS) {
                EmpTuple emp = loadEmp(empfile);
                mem[mem_idx++].emp = emp;
            }
        }
        catch (NoMoreTuplesException &e) {
            empfile.close();
            theresMore = false;
        }
        // In-memory sort of this chunk
        qsort(mem, mem_idx, sizeof(Tuple), &empCompar);
        // Dump it to a new temporary file
        ofstream tmpfile;
        tmpOpen(tmpfile, tmp_file_idx++);
        for (int i = 0; i < mem_idx; i++) {
            writeEmp(tmpfile, mem[i].emp);
        }
    }
    // Our temporary files are numbered from min_tmp_idx to max_tmp_idx.
    max_tmp_idx = tmp_file_idx - 1;

    // Merge two of the temporary files into another until only one temporary file
    // remains.
    while (min_tmp_idx < max_tmp_idx) {

        // Open two files to merge
        ifstream tmpfile1, tmpfile2;
        tmpOpen(tmpfile1, min_tmp_idx++);
        tmpOpen(tmpfile2, min_tmp_idx++);

        // Open the output file
        ofstream outfile;
        tmpOpen(outfile, ++max_tmp_idx);

        bool file1HasMore = true, file2HasMore = true;

        // Allocate mem as two input buffers, one for each file.
        // "start" is inclusive; "end" is exclusive.
        // At all times when the indexes are valid, we have
        //     buf1_start <= buf1_idx < buf1_end
        //     buf2_start <= buf2_idx < buf2_end
        int buf1_start = 0, buf1_end = NUM_BLOCKS / 2;
        int buf2_start = NUM_BLOCKS / 2, buf2_end = NUM_BLOCKS;

        // Initialize the indexes to be invalid to trigger the loop to load
        // from the files in the first iteration.
        int buf1_idx = buf1_end, buf2_idx = buf2_end;

        // The merge loop ends after both lists are exhausted, but it's better
        // to check after we fetch more into memory, because it's possible
        // that we fetch 0, and we can't tell that until we try.
        while (true) {
            if (buf1_idx >= buf1_end && file1HasMore) {
                // The tmpfile1 buffer is empty; let's load more.
                try {
                    for (buf1_idx = buf1_start; buf1_idx < buf1_end; buf1_idx++) {
                        mem[buf1_idx].emp = loadEmp(tmpfile1);
                    }
                }
                catch (NoMoreTuplesException &e) {
                    file1HasMore = false;
                }
                buf1_end = buf1_idx;
                buf1_idx = buf1_start;
            }
            if (buf2_idx >= buf2_end && file2HasMore) {
                // Get more into the tmpfile2 buffer
                try {
                    for (buf2_idx = buf2_start; buf2_idx < buf2_end; buf2_idx++) {
                        mem[buf2_idx].emp = loadEmp(tmpfile2);
                    }
                }
                catch (NoMoreTuplesException &e) {
                    file2HasMore = false;
                }
                buf2_end = buf2_idx;
                buf2_idx = buf2_start;
            }
            if (!file1HasMore && !file2HasMore
                        && buf1_idx >= buf1_end && buf2_idx >= buf2_end) {
                // Merge is complete!
                break;
            }
            // Determine which buffer has the next smallest emp.eid and write it.
            EmpTuple smallerEmp;
            if (buf2_idx >= buf2_end)
                smallerEmp = mem[buf1_idx++].emp;
            else if (buf1_idx >= buf1_end)
                smallerEmp = mem[buf2_idx++].emp;
            else if (mem[buf1_idx].emp.eid <= mem[buf2_idx].emp.eid)
                smallerEmp = mem[buf1_idx++].emp;
            else
                smallerEmp = mem[buf2_idx++].emp;
            writeEmp(outfile, smallerEmp);
        }
        // Close the files; the next iteration may open three different files,
        // or may use outfile as one of the inputs.
        tmpfile1.close();
        tmpfile2.close();
        outfile.close();
    }

    // The last temporary file we wrote contains the whole sorted relation.
    // We've closed the file, but the caller will reopen it.
    if (DEBUG) {
        cerr << "External sort completed in tmp file index " << max_tmp_idx << endl;
    }
    return max_tmp_idx;
}

int main() {
    // Make a version of Emp.csv sorted on eid and get the filename
    if (DEBUG) {
        cerr << "Externally sorting Emp file" << endl;
    }
    int emp_sorted_tmp_idx = external_emp_sort();

    // Load Dept file (it contains 15 tuples, small enough to fit in memory)
    // This is probably a segfault if Dept is too large.
    // A Dept file of exactly 22 tuples causes an infinite loop, because
    // there's no room for the Emp input buffer later.
    int mem_idx = 0;
    ifstream deptfile;
    if (DEBUG) {
        cerr << "Loading Dept file" << endl;
    }
    deptfile.open(DEPT_FILENAME, ifstream::in);
    try {
        while (true) {
            DeptTuple dept = loadDept(deptfile);
            mem[mem_idx++].dept = dept;
        }
    }
    catch (NoMoreTuplesException &e) {
        deptfile.close();
    }

    // In-memory sort of Dept file
    // We actually sort it *backwards* so that higher mem_idx are consumed first,
    // leaving extra room for the Emp input buffer on subsequent refills.
    if (DEBUG) {
        cerr << "In-memory sorting Dept file" << endl;
    }
    qsort(mem, mem_idx, sizeof(Tuple), &deptCompar);
    int dept_idx = mem_idx - 1;

    // Open the temporary file containing the sorted Emp relation
    ifstream empfile;
    tmpOpen(empfile, emp_sorted_tmp_idx);
    int emp_end = NUM_BLOCKS;  // one past the end of the Emp buffer
    int emp_idx = NUM_BLOCKS;  // trigger input buffer to load in a moment
    bool empHasMore = true;

    // Open the output file
    ofstream outfile;
    outfile.open(OUTPUT_FILENAME);

    while ((empHasMore || emp_idx < emp_end) && dept_idx >= 0) {
        // handle empty Emp buffer
        if (emp_idx >= emp_end && empHasMore) {
            // Load as many Emp tuples as we can
            emp_idx = dept_idx + 1;
            emp_end = NUM_BLOCKS;
            if (DEBUG) {
                cerr << "Loading up to " << emp_end - emp_idx
                     << " Emp tuples [" << emp_idx << "-" << emp_end - 1
                     << "]" << endl;
            }
            try {
                while (emp_idx < emp_end) {
                    mem[emp_idx++].emp = loadEmp(empfile);
                }
            }
            catch (NoMoreTuplesException &e) {
                empHasMore = false;
                empfile.close();
                if (DEBUG) {
                    cerr << "Only " << emp_idx - dept_idx - 2 << " Emp tuples loaded." << endl;
                }
            }
            if (emp_idx == dept_idx + 1) break;  // there weren't any more Emps
            emp_end = emp_idx;
            emp_idx = dept_idx + 1;  // ready for merging
        }

        // advance the indexes looking for a match
        while (dept_idx >= 0 && emp_idx < emp_end &&
               mem[dept_idx].dept.managerid != mem[emp_idx].emp.eid) {
            if (mem[dept_idx].dept.managerid < mem[emp_idx].emp.eid) {
                dept_idx--;  // remember, Dept is sorted backwards in memory
            }
            else {
                emp_idx++;
            }
        }

        // check for one or more matches
        while (dept_idx >= 0 &&
               mem[dept_idx].dept.managerid == mem[emp_idx].emp.eid) {
            // Output a tuple
            writeJoin(outfile, mem[dept_idx].dept, mem[emp_idx].emp);

            // This join is one-to-many, because emp.eid is unique and
            // dept.managerid is not.  We'll advance dept_idx and see
            // if the same employee manages the next department, too.
            dept_idx--;
        }
    }

    empfile.close();
    outfile.close();

    if (!DEBUG) {
        // remove all temporary files we created
        for (int i = 1; i <= tmp_file_idx; i++) {
            char filename[TMP_FILENAME_MAX_LENGTH + 1];
            snprintf(filename, TMP_FILENAME_MAX_LENGTH + 1, TMP_FILENAME_TEMPLATE, i);
            remove(filename);
        }
    }

    return 0;
}
