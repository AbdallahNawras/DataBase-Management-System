#include <iostream>
#include <fstream>
#include <cstring>
#include <cstdlib>
#include <cmath>

#define DEBUG false

using namespace std;

const int NUM_BLOCKS = 22; // available memory
const char* EMP_FILENAME = "Emp.csv";
const char* OUTPUT_FILENAME = "EmpSorted.csv";
const char* TMP_FILENAME_TEMPLATE = "main4_tmp%02d.csv";
const int TMP_FILENAME_MAX_LENGTH = strlen(TMP_FILENAME_TEMPLATE) + 6;

int tmp_file_idx = 1;

// Helper function to open a numbered temporary file
void tmpOpen(ifstream &f, int idx) {
    char *filename = new char[TMP_FILENAME_MAX_LENGTH + 1];
    snprintf(filename, TMP_FILENAME_MAX_LENGTH + 1, TMP_FILENAME_TEMPLATE, idx);
    f.open(filename, ios::in);
    delete filename;
}

void tmpOpen(ofstream &f, int idx) {
    char *filename = new char[TMP_FILENAME_MAX_LENGTH + 1];
    snprintf(filename, TMP_FILENAME_MAX_LENGTH + 1, TMP_FILENAME_TEMPLATE, idx);
    f.open(filename, ofstream::trunc);
    delete filename;
}

typedef struct {
    int eid;
    char ename[40];
    int age;
    double salary;
} EmpTuple;

// An exception for signaling EOF
struct NoMoreTuplesException : public exception {
    const char *what() const throw() {
        return "EOF";
    }
};

// Load one Emp tuple from an already-open Emp.csv file
EmpTuple loadEmp(ifstream &in) {
    char line[80];
    EmpTuple emp;
    in.getline(line, 80);
    if (in.eof()) throw NoMoreTuplesException();
    emp.eid=atoi(strtok(line, ","));
    strncpy(emp.ename, strtok(NULL, ","), 40);
    emp.age=atoi(strtok(NULL, ","));
    emp.salary=atof(strtok(NULL, "\n"));
    return emp;
}

// Write an Emp tuple to disk
void writeEmp(ostream &out, EmpTuple emp) {
    out << emp.eid << "," << emp.ename << "," << emp.age << "," << (long)emp.salary
        << endl;
}

// Internal memory is limited to NUM_BLOCKS tuples
EmpTuple mem[NUM_BLOCKS];

// Comparator function for qsort and merging
int empCompar(const void* p1, const void* p2) {
    if (((EmpTuple *)p1)->eid < ((EmpTuple *)p2)->eid) return -1;
    if (((EmpTuple *)p1)->eid > ((EmpTuple *)p2)->eid) return 1;
    return 0;
}

// Read some tuples, sort, write to next tmp file.
// Returns the number of tuples processed.
int sortChunk(ifstream &empfile) {
    int mem_idx = 0;
    try {
        while (mem_idx < NUM_BLOCKS) {
            mem[mem_idx++] = loadEmp(empfile);
        }
    }
    catch (NoMoreTuplesException &ex) {
        mem_idx--;  // Didn't actually load that one after all
    }
    if (mem_idx > 0) { // if loaded any...
        qsort(mem, mem_idx, sizeof(EmpTuple), &empCompar);
        ofstream tmpfile;
        tmpOpen(tmpfile, tmp_file_idx++);
        for (int i = 0; i < mem_idx; i++) {
            writeEmp(tmpfile, mem[i]);
        }
        tmpfile.close();
    }
    return mem_idx;
}

void multiwayMerge(int tmp_start, int tmp_end) {
    int K = tmp_end - tmp_start; // do a K-way merge
    if (K > NUM_BLOCKS) {
        cerr << "Internal error, K too large" << endl;
        return;
    }

    ofstream outfile;
    tmpOpen(outfile, tmp_file_idx++);

    // Set up K input buffers, each from mem[s[i]], inclusive,
    // to mem[e[i]], exclusive.
    ifstream tmpfile[NUM_BLOCKS + 1];
    bool more[NUM_BLOCKS + 1];  // whether each file should be read again
    int s[NUM_BLOCKS + 1];  // start of each buffer
    int idx[NUM_BLOCKS];    // position in each buffer
    int e[NUM_BLOCKS];      // 1 past the end of the occupied
                            // portion of each buffer
    for (int i = 0; i < K; i++) {
        e[i] = idx[i] = s[i] = NUM_BLOCKS * i / K;
        more[i] = true;
        // Open that file
        tmpOpen(tmpfile[i], tmp_start + i);
    }
    s[K] = NUM_BLOCKS;

    while (true) {
        // Refill buffers as necessary
        bool done = true;
        for (int i = 0; i < K; i++) {
            if (idx[i] >= e[i]) {
                // Load from tmpfile[i] into this buffer
                if (more[i]) {
                    e[i] = idx[i] = s[i];
                    try {
                        mem[e[i]++] = loadEmp(tmpfile[i]);
                    }
                    catch (NoMoreTuplesException &ex) {
                        more[i] = false;
                        e[i]--;  // Didn't actually load that one
                    }
                    if (idx[i] < e[i]) done = false;
                }
            }
            else {
                done = false;
            }
        }
        if (done) break;

        // Scan for minimum element
        int min_i = -1;
        for (int i = 0; i < K; i++) {
            if (idx[i] < e[i]) {
                if (min_i < 0 || mem[idx[i]].eid < mem[idx[min_i]].eid)
                    min_i = i;
            }
        }

        // Write record to merged file
        writeEmp(outfile, mem[idx[min_i]++]);
    }
}

int main() {
    ifstream empfile;
    empfile.open(EMP_FILENAME);
    int numTuples = 0;
    int numLoaded;
    int tmp_idx_start = tmp_file_idx;

    // Internally sort chunks of NUM_BLOCKS tuples into temporary files
    while (numLoaded = sortChunk(empfile)) {
        numTuples += numLoaded;
        if (numLoaded < NUM_BLOCKS) break;
    }

    // Compute the K in K-way merge
    if (DEBUG) {
        cerr << "Loaded " << numTuples << " tuples" << endl;
    }
    int K = ceil(pow(numTuples, 1.0/3));
    if (K > NUM_BLOCKS) {
        cerr << "Too many tuples for 2-pass merge" << endl;
        return 1;
    }
    if (DEBUG) {
        cerr << "Using " << K << "-way merges" << endl;
    }

    int tmp_idx_end = tmp_file_idx;

    // Merge as many passes as needed
    while (tmp_idx_start < tmp_idx_end - 1) {
        for (int i=tmp_idx_start; i<tmp_idx_end; i += K) {
            int j = i + K;
            if (j >= tmp_idx_end) j = tmp_idx_end;
            if (DEBUG) {
                cerr << "Starting " << j-i
                     << "-way merge (" << i << " through "
                     << j-1 << ")" << endl;
            }
            multiwayMerge(i, j);
        }
        tmp_idx_start = tmp_idx_end;
        tmp_idx_end = tmp_file_idx;
    }

    // Rename the latest tmp file to output
    char *filename  = new char[TMP_FILENAME_MAX_LENGTH + 1];
    snprintf(filename, TMP_FILENAME_MAX_LENGTH + 1, TMP_FILENAME_TEMPLATE, --tmp_file_idx);
    rename(filename, OUTPUT_FILENAME);
    delete filename;

    if (!DEBUG) {
        // remove all temporary files we created
        for (int i = 1; i <= tmp_file_idx; i++) {
            char filename[TMP_FILENAME_MAX_LENGTH + 1];
            snprintf(filename, TMP_FILENAME_MAX_LENGTH + 1, TMP_FILENAME_TEMPLATE, i);
            remove(filename);
        }
    }

}
