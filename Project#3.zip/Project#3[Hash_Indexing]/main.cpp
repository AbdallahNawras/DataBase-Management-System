//Abdallah Nawras
//nawrasa@oregonstate.edu
//ID:934069685
//Group#49
#include <iostream>
#include <fstream>
#include <cstring>
#include <string>
#include <vector>

#define BLOCK_SIZE 4096
#define DEBUG false

// BIG_N is N in the original Litwin paper
int BIG_N = 7;

using namespace std;

const char* CSV_FILENAME = "Employee.csv";
const char* INDEX_FILENAME = "EmployeeIndex";
const float MAX_LOAD_FACTOR = 0.8;

// The FileHeader is the very first BLOCK_SIZE bytes of the file.
// Required metadata can go here.
struct FileHeader {
    unsigned int num_blocks;  // Number of primary blocks in the file
    unsigned int N;           // The big-N value used at creation time
    char padding[BLOCK_SIZE - 8] = {'\0'}; // Keep the rest of the blocks aligned
};

// One block of the file on disk
struct Block {
    unsigned int overflow = 0;   // Index of next overflow block
    unsigned int size = 0;       // Number of valid bytes in records
    char data[BLOCK_SIZE - 8] = {'\0'};   // Zero or more records of variable length


};

// One record in memory
// "name" and "bio" must be variable length on disk, otherwise it will be
// nowhere close to 80% target utilization.
struct Record {
    char id[9];        // id[8] is '\0', but not stored to disk
    char *name;        // Variable length, up to 201 including null terminator
    char *bio;         // Variable length up to 501
    char manager_id[9];// Room for null terminator, not stored to disk
};

// Display usage message when command-line parameters are incorrect
int usage(char *name) {
    cout << endl;
    cout << "Usage:" << endl;
    cout << "  " << name << " -C" << endl;
    cout << "    Creates file EmployeeIndex based on Employee.csv" << endl;
    cout << endl;
    cout << "  " << name << " -L <id>" << endl;
    cout << "    Retrieves and displays the record from the EmployeeIndex file" << endl;
    cout << "    with the specified id" << endl;
    cout << endl;
    cout << "  " << name << " -D" << endl;
    cout << "    Loads the EmployeeIndex file and prints some diagnostics" << endl;
    cout << endl;
    return 1;
}

// Compute the level parameter of get_hash() given a number of
// primary blocks. This will save recomputing it all the time.
unsigned int get_level(unsigned int num_blocks) {
    unsigned int m = num_blocks / BIG_N;
    unsigned int highbit = 0;
    // highbit is the position of the highest 1-bit in m, counting from 1.
    while (m) {
        m >>= 1;
        highbit++;
    }
    // highbit + 1 is the "file level", the highest split of the hash
    // that could be in use for this num_blocks.
    return highbit;
}

// Given id, a string of exactly 8 characters, and some parameters about
// the hash table, return which bucket it belongs to.
unsigned int get_hash(char *id, unsigned int num_blocks, unsigned int level) {

    // Compute the djb2 hash, invented by Daniel J. Bernstein
    unsigned int hash = 5381;
    for (int i=0; i<9; i++) {
        hash = 33 * hash + id[i];
    }

    // Reduce according to the file level
    hash = hash % (BIG_N*(1<<level));
    if (hash >= num_blocks) {
        // This block hasn't been split off yet, so use the block that
        // will eventually split into it.
        hash -= BIG_N * (1<<(level-1));
    }
    return hash;
}

// Read the CSV file and find out how many primary blocks the idnex should use.
vector<Record> load_records_from_csv() {
    // TODO: enforce EXACTLY 8 bytes for id (else the hash function breaks)
    ifstream csv_file;
    char id[9], name[201], bio[501], m_id[9];

    vector<Record> records;

    csv_file.open(CSV_FILENAME);
    int n = 0;
    while (!csv_file.eof()) {
        // Read fields into maximally-sized buffers
        csv_file.getline(id,9,',');
        if (csv_file.eof()) break;
        csv_file.getline(name,201,',');
        csv_file.getline(bio,501,',');
        csv_file.getline(m_id,9);

        // Zero out bytes after id terminator, in case it's a short string
        for (int i = 0; i < 8; i++) {
            if (id[i] != '\0') continue;
            for (; i < 8; i++) {
                id[i] = '\0';
            }
        }

        // Allocate Record and copy over the static fields
        Record r;
        strcpy(r.id, id);
        strcpy(r.manager_id, m_id);

        // Allocate dynamic fields and put pointers into the Record
        char *r_name = new char[strlen(name) + 1];
        char *r_bio = new char[strlen(bio) + 1];
        strcpy(r_name, name);
        strcpy(r_bio, bio);
        r.name = r_name;
        r.bio = r_bio;

        // Add this record to the in-memory list
        records.push_back(r);
    }
    csv_file.close();
    if (DEBUG) cerr << "Loaded " << records.size() << " records from CSV" << endl;
    return records;

}

unsigned int get_required_n(vector<Record> records) {
    int total_size = 0;
    for (auto r : records) {
        total_size += 9                   // id with null terminator
                    + strlen(r.name) + 1  // name with null terminator
                    + strlen(r.bio) + 1   // bio with null terminator
                    + 9;                  // manager_id with null terminator
    }
    int payload_block_size = BLOCK_SIZE - 8; // size of the Block.data field

    unsigned int little_n;
    // increment n whenever load factor is over MAX_LOAD_FACTOR
    little_n = (int)(total_size / (MAX_LOAD_FACTOR * payload_block_size) + 1);
    if (little_n < BIG_N) {
        // BIG_N is the minimum number of buckets before any splits.
        little_n = BIG_N;
    }
    return little_n;
}

// Find and load the overflow block for b, using the output parameters.
void follow_overflow(fstream &index_file, Block &b, unsigned int &blockpos) {
    if (DEBUG) cerr << "Overflowing from " << blockpos << endl;
    blockpos = (b.overflow + 1) * BLOCK_SIZE;
    index_file.seekg(blockpos);
    index_file.read((char *)&b, BLOCK_SIZE);
    if (DEBUG) cerr << "Following to " << blockpos << endl;
}

// Read the CSV file and create the employee hash index file.
// Return 0 on success, nonzero on failure.
int create_index(vector<Record> records, unsigned int n) {
    // Open output file.
    fstream index_file;
    index_file.open(INDEX_FILENAME, ios::binary | ios::in | ios::out | ios::trunc);

    // Write the header to disk.
    FileHeader file_header;
    file_header.num_blocks = n;
    file_header.N = BIG_N;
    index_file.write((char *)&file_header, BLOCK_SIZE);

    // Write empty primary blocks to disk.
    for (int i = 0; i < n; i++) {
        Block block;
        index_file.write((char *)&block, BLOCK_SIZE);
    }

    unsigned int num_overflows = 0;  // How many overflow blocks exist?

    unsigned int level = get_level(n);

    // Insert each record using the linear hashing mechanism.
    // read the block, add the record, and write the block.
    for (Record r : records) {
        // Figure out how much space is needed
        int id_size = 9;
        int name_size = strlen(r.name) + 1;
        int bio_size = strlen(r.bio) + 1;
        int mid_size = 9;
        int size = id_size + name_size + bio_size + mid_size;

        if (DEBUG) cerr << "Inserting " << r.name << endl;

        // Find this record's primary bucket
        unsigned int h = get_hash(r.id, n, level);

        if (h >= n) {
            cerr << "Internal error: Hash index " << h
                 << " is too big for " << n << " primary blocks, N=" << BIG_N
                 << endl;
            return 255;
        }

        // Load the primary bucket
        unsigned int blockpos = BLOCK_SIZE * (1 + h);
        index_file.seekg(blockpos);
        Block b;
        index_file.read((char *)&b, BLOCK_SIZE);

        // Move to an overflow block if there's not enough space
        // Be sure to update blockpos so write to the right one later!
        while (b.size + size > BLOCK_SIZE - 8) {
            if (b.overflow == 0) {
                // Block is full and has no overflow block,
                // so we will have to make one.
                b.overflow = n + num_overflows++;
                // Since the overflow field comes first, write just these 8 bytes to disk.
                index_file.seekp(blockpos);
                index_file.write((char *)&b, 8);
                // Reinitialize b to use it as a new on-disk block
                b.overflow = 0;
                b.size = 0;
                for (int i=0; i<BLOCK_SIZE-8; i++) {
                    b.data[i] = '\0';
                }
                blockpos = (n + num_overflows) * BLOCK_SIZE;
            }
            else {
                // An overflow block exists, so load it.
                follow_overflow(index_file, b, blockpos);
            }
        }
        // Append r to b.data
        strcpy(b.data + b.size, r.id);
        strcpy(b.data + b.size + id_size, r.name);
        strcpy(b.data + b.size + id_size + name_size, r.bio);
        strcpy(b.data + b.size + id_size + name_size + bio_size, r.manager_id);
        b.size += size;
        // Write the modified block to disk
        if (DEBUG) cerr << "Writing for hash " << h << " to block at " << blockpos << endl;
        index_file.seekp(blockpos);
        index_file.write((char *)&b, BLOCK_SIZE);
    }

    index_file.close();
    return 0;
}

// Retrieve and display a record by id.
// n is the number of primary blocks in the file.
int display_record_with_id(char *id) {
    // Check length of id and alert the user
    if (strlen(id) != 8) {
        cerr << "WARNING: ID is not exactly 8 characters long" << endl;
    }

    // Load index file metadata block
    fstream index_file;
    index_file.open(INDEX_FILENAME, ios::in | ios::binary);
    FileHeader header;
    index_file.read((char *)&header, BLOCK_SIZE);

    // Load metadata from header
    unsigned int n = header.num_blocks;
    BIG_N = header.N;   // In case the index was written with a different value

    // Get hash
    unsigned int level = get_level(n);
    unsigned int h = get_hash(id, n, level);

    // Fetch the primary bucket
    unsigned int blockpos = BLOCK_SIZE * (1 + h);
    index_file.seekg(blockpos);
    Block b;
    index_file.read((char *)&b, BLOCK_SIZE);

    Record r;
    bool found = false;
    // Look for the record within the block(s)
    int recordpos = 0;
    if (DEBUG) cout << "Checking block at " << blockpos << " of size " << b.size << endl;
    while (true) {
        while (recordpos < b.size) {
            strncpy(r.id, b.data + recordpos, 9);
            recordpos += 9;
            char buffer[501];
            int len;
            if (strcmp(r.id, id) == 0) {
                // Found it, now load the fields into r
                found = true;
                int i;
                // Copy name
                strncpy(buffer, b.data + recordpos, 201);
                len = strlen(buffer);
                r.name = new char[len + 1];
                strncpy(r.name, buffer, len + 1);
                recordpos += len + 1;
                // Copy bio
                strncpy(buffer, b.data + recordpos, 501);
                len = strlen(buffer);
                r.bio = new char[len + 1];
                strncpy(r.bio, buffer, len + 1);
                recordpos += len + 1;
                // Copy manager_id
                strncpy(r.manager_id, b.data + recordpos, 9);
                break;
            }
            else {
                // Skip this record, check the next
                recordpos += strlen(b.data + recordpos) + 1;  // skip name
                recordpos += strlen(b.data + recordpos) + 1;  // skip bio
                recordpos += strlen(b.data + recordpos) + 1;  // skip manager_id
            }
        }
        if (found) {
            cout << "ID:\t\t" << r.id << endl;
            cout << "Name:\t\t" << r.name << endl;
            cout << "Bio:\t\t" << r.bio << endl;
            cout << "Manager ID:\t" << r.manager_id << endl;
            return 0;
        }
        else {
            if (b.overflow > 0) {
                if (DEBUG) cout << "Checking overflow..." << endl;
                follow_overflow(index_file, b, blockpos);
                recordpos = 0;
                continue;
            }
            else {
                // looked everywhere
                cout << "Record not found!" << endl;
                return 1;
            }
        }
    }
}

int display_diagnostics() {
    fstream index_file;
    index_file.open(INDEX_FILENAME, ios::in | ios::binary);
    int idx = 0;
    FileHeader header;
    index_file.read((char *)&header, BLOCK_SIZE);
    cout << INDEX_FILENAME << " diagnostics:" << endl;
    cout << "BIG_N:         \t" << header.N << endl;
    cout << "Primary blocks:\t" << header.num_blocks << endl << endl;
    int num_blocks = header.num_blocks;
    int total_size = 0;
    while (true) {
        idx++;
        Block b;
        index_file.read((char *)&b, BLOCK_SIZE);
        if (index_file.eof()) break;
        cout << "Block index " << idx;
        if (idx <= num_blocks) cout << " (primary):";
        else cout << " (overflow):";
        cout << endl;
        if (b.overflow == 0) cout << "\tNo overflow" << endl;
        else cout << "\tOverflow: " << b.overflow << endl;
        total_size += b.size;
        cout << "\tUsage:\t" << b.size << "\t/ " << BLOCK_SIZE << endl;
    }
    cout << endl;
    cout << "Total usage:\t" << total_size << " / " << (BLOCK_SIZE * idx);
    float usage_ratio = total_size * 100. / (BLOCK_SIZE * idx);
    cout << "  (" << usage_ratio << "%)" << endl << endl;
    return 0;
}

int main(int argc, char **argv) {
    if (argc == 2 && strcmp(argv[1], "-C") == 0) {
        vector<Record> records = load_records_from_csv();
        unsigned int n = get_required_n(records);
        if (DEBUG) cerr << n << " blocks to allocate" << endl;
        return create_index(records, n);
    }
    else if (argc == 2 && strcmp(argv[1], "-D") == 0) {
        return display_diagnostics();
    }
    else if (argc == 3 && strcmp(argv[1], "-L") == 0) {
        return display_record_with_id(argv[2]);
    }
    else {
        return usage(argv[0]);
    }

    return 0;
}
